#ifndef GTM_DECODER_EXTRACT_SCIENCE_DATA_H
#define GTM_DECODER_EXTRACT_SCIENCE_DATA_H

void extract_science_data(void);

#endif