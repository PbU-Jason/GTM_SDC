#include "GTM_Decoder_Parse_Both_TMTC_Science_Data.h"

void parse_both_tmtc_science_data(void) {
    
}

