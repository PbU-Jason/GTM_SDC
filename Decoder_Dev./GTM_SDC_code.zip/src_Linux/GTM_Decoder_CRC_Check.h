#ifndef GTM_DECODER_CRC_CHECK_H
#define GTM_DECODER_CRC_CHECK_H

uint8_t calc_CRC_8_ATM_rev(unsigned char *Target, size_t TargetSize);

#endif