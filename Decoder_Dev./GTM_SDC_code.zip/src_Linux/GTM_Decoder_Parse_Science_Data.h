#ifndef GTM_DECODER_PARSE_SCIENCE_DATA_H
#define GTM_DECODER_PARSE_SCIENCE_DATA_H

void parse_science_data(void);

#endif