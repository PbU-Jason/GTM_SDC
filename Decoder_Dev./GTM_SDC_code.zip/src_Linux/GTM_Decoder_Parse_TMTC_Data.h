#ifndef GTM_DECODER_PARSE_TMTC_DATA_H
#define GTM_DECODER_PARSE_TMTC_DATA_H

void parse_tmtc_data(void);

#endif